// C:\Mestrado_Projetos\Pesquisa\Projeto_Mestrado_v10\client\src\hooks\useVoiceRecognition.js

import { useState, useRef, useCallback, useEffect } from 'react';

// A taxa de amostragem que o servidor Vosk espera. É crucial que o áudio chegue neste formato.
const TARGET_SAMPLE_RATE = 16000;

const useVoiceRecognition = (onTranscription, onSuggestions) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState(null);

  const socketRef = useRef(null);
  const audioContextRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const audioProcessorRef = useRef(null);

  const resampleBuffer = (inputBuffer, targetSampleRate) => {
    const inputSampleRate = audioContextRef.current.sampleRate;
    if (inputSampleRate === targetSampleRate) {
      return inputBuffer;
    }
    const sampleRateRatio = inputSampleRate / targetSampleRate;
    const newLength = Math.round(inputBuffer.length / sampleRateRatio);
    const result = new Float32Array(newLength);
    let offsetResult = 0;
    let offsetBuffer = 0;
    while (offsetResult < result.length) {
      const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
      // CORREÇÃO DA REGRA 'one-var' AQUI TAMBÉM
      let accum = 0;
      let count = 0;
      for (
        let i = offsetBuffer;
        i < nextOffsetBuffer && i < inputBuffer.length;
        i++
      ) {
        accum += inputBuffer[i];
        count++;
      }
      result[offsetResult] = accum / count;
      offsetResult++;
      offsetBuffer = nextOffsetBuffer;
    }
    return result;
  };

  const floatTo16BitPCM = (input) => {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  };

  const stopVoiceRecognition = useCallback(() => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(console.error);
    }
    if (audioProcessorRef.current) {
      audioProcessorRef.current.disconnect();
    }
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ eof: 1 }));
      socketRef.current.close();
    }
    setIsRecording(false);
    setIsConnected(false);
    console.log('Reconhecimento de voz parado e recursos liberados.');
  }, []);

  const startVoiceRecognition = useCallback(async () => {
    if (isRecording) {
      return;
    }
    setError(null);

    const wsUrl =
      process.env.REACT_APP_VOICE_WS_URL ||
      'ws://127.0.0.1:8000/ws/transcricao_em_tempo_real';
    // 'ws://127.0.0.1:8000/ws/recom_tempo_real';
    socketRef.current = new WebSocket(wsUrl);

    socketRef.current.onopen = async () => {
      console.log('WebSocket conectado. Iniciando captura de áudio...');
      setIsConnected(true);

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });
        mediaStreamRef.current = stream;

        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioContextRef.current = new AudioContext();

        const source = audioContextRef.current.createMediaStreamSource(stream);
        const processor = audioContextRef.current.createScriptProcessor(
          4096,
          1,
          1
        );
        audioProcessorRef.current = processor;

        processor.onaudioprocess = (event) => {
          if (socketRef.current?.readyState !== WebSocket.OPEN) {
            return;
          }

          const rawFloatData = event.inputBuffer.getChannelData(0);

          const resampledData = resampleBuffer(
            rawFloatData,
            TARGET_SAMPLE_RATE
          );

          const pcmData = floatTo16BitPCM(resampledData);

          socketRef.current.send(pcmData.buffer);
        };

        source.connect(processor);
        processor.connect(audioContextRef.current.destination);
        setIsRecording(true);
      } catch (mediaError) {
        console.error('Erro ao acessar microfone:', mediaError);
        setError('Erro ao acessar o microfone. Verifique as permissões.');
        stopVoiceRecognition();
      }
    };

    socketRef.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log('Mensagem do servidor:', data);

        if (
          data.tipo === 'transcricao_parcial' ||
          data.tipo === 'transcricao_final'
        ) {
          onTranscription(data.texto);
        } else if (data.tipo === 'sugestao_contextual') {
          onSuggestions(data.sugestoes);
        } else if (data.tipo === 'erro') {
          setError(data.detalhe); // Corrigido 'dethe' para 'detalhe'
        }
      } catch (parseError) {
        console.error('Erro ao processar mensagem do servidor:', parseError);
      }
    };

    socketRef.current.onclose = () => {
      console.log('WebSocket desconectado.');
      stopVoiceRecognition();
    };

    socketRef.current.onerror = (wsError) => {
      console.error('Erro no WebSocket:', wsError);
      setError('Erro na conexão com o servidor de voz.');
      stopVoiceRecognition();
    };
  }, [isRecording, onTranscription, onSuggestions, stopVoiceRecognition]);

  const toggleRecording = useCallback(() => {
    if (isRecording) {
      stopVoiceRecognition();
    } else {
      startVoiceRecognition();
    }
  }, [isRecording, startVoiceRecognition, stopVoiceRecognition]);

  useEffect(() => {
    return () => {
      stopVoiceRecognition();
    };
  }, [stopVoiceRecognition]);

  return {
    isRecording,
    isConnected,
    error,
    toggleRecording,
  };
};

export default useVoiceRecognition;
